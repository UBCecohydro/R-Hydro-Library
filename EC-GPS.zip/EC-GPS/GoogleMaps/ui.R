####
# user interface file to plot EC-GPS Data to google maps and format data for clean download.
####
# Needed files:
    #1) server.R (R server file)
    #2) ui.R (user interface file)
    #3) www folder containing 'map.html' (html file with JSON code to plot points to google maps)

# INSTRUCTIONS (more detail in readme.txt)
#1) Make sure that you have R installed on your computer (R downloads with RGUi by default; RStudio is optional but a bit nicer)
#2) Make sure that all needed R packages are installed and up to date; This code was built with R version 3.5.0 (2018-04-23)
    ## CODE to install needed packages (if asked install dependancies)
    #install.packages(c('shiny','readr','DT','RJSONIO','dplyr','tidyr'))
    ## CODE to update needed packages (if previously installed)
    #update.packages(c('shiny','readr','DT','RJSONIO','dplyr','tidyr'))
#3) Ensure that the 'ui.R' file, 'server.R' file, and 'www' folder (containing 'map.html') are in the same folder. 
#4) Run the Shiny app in RGUi or RStudio
    #RStudio: a)"Run App" button or in Console 'shiny::runApp()' or 'shiny::runApp('YOUR CONTAINING FOLDER LOCATION')'; containing folder location should be something like 'C:/Users/userName/Documents/EC-GPS/GoogleMaps'
        #b)depending on RStudio settings you may need to click the "Open in Browser" button 
    #RGui: shiny::runApp('YOUR CONTAINING FOLDER LOCATION'); containing folder location should be something like 'C:/Users/userName/Documents/EC-GPS/GoogleMaps'
#5) upload desired data file and manipulate (can use included file 'LOG_MMDD.TXT' to test)
    # set time zone
    # filter by date
    # filter by EC value (check box and sliders)
    # plot to map "Plot Data"
        # Note 1: data needs to be replotted after filters are changed
        # Note 2: clicking on data points on the map displays the details associated
# Download Processed Data to .csv file that can be opened in Microsoft Excel or other text editor
    # Additionally Data can be sorted and searched using the Search bar and controls on the data table
####

#USER INTERFACE CODE BELOW
# define components of page
ui <- fluidPage(
    titlePanel("EC-GPS Data"), ## webpage title
    sidebarLayout( ## define layout type
        sidebarPanel( ## sidebar for filters and inputs
            fileInput("dataInput", "Choose LOG.txt File", accept = ".txt"), ## import local file to view
            ## Data manipulation and filters
            selectInput("tzInput", "Time Zone", 
                        choices = list('Canada/Atlantic','Canada/Central','Canada/Eastern', 
                                       'Canada/East-Saskatchewan','Canada/Mountain', 'Canada/Newfoundland',
                                       'Canada/Pacific', 'Canada/Saskatchewan','Canada/Yukon','UTC(default)'="UTC"),
                        selected = 'UTC',
                        multiple = FALSE),
            uiOutput("Date_filter"),
            checkboxInput("ECFilter", "Filter by EC?", FALSE), #default sort by Date
            uiOutput("EC_filter"),
            ## Data download
            downloadButton("dataDownload", "Download Processed Data")
        ),
        ## Main panel for map
        mainPanel(
            actionButton('draw','Plot Data'),
            includeHTML('www/map.html'),
            textOutput("result") ## debugging text output (won't print anything unless corresponding section is uncommented in server.R)
        )
    ),
    ## results table below map and inputs
    fluidRow(DT::dataTableOutput("results"))
)