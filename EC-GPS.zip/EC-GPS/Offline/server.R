####
# Server file to plot EC-GPS Data to Canadian provincial polygons and format data for clean download.
####
# Needed files:
    #1) server.R (R server file)
    #2) ui.R (user interface file)
    #3) GADM_2.8_CAN_adm1.rds (provincial basemap for plotting data; can be downloaded by running raster::getData("GADM",country="CAN",level=1))

# INSTRUCTIONS (more detail in readme.txt)
#1) Make sure that you have R installed on your computer (R downloads with RGUi by default; RStudio is optional but a bit nicer)
#2) Make sure that all needed R packages are installed and up to date; This code was built with R version 3.5.0 (2018-04-23)
    ## CODE to install needed packages (if asked install dependancies)
    #install.packages(c('shiny','readr','DT','dplyr','tidyr','sp','broom','ggplot2'))
    ## CODE to update needed packages (if previously installed)
    #update.packages(c('shiny','readr','DT','dplyr','tidyr','sp','broom','ggplot2'))
#3) Ensure that the 'ui.R' file, 'server.R' file, and 'GADM_2.8_CAN_adm1.rds' file are in the same folder. 
#4) Run the Shiny app in RGUi or RStudio
    #RStudio:"Run App" button or in Console 'shiny::runApp()' or 'shiny::runApp('YOUR CONTAINING FOLDER LOCATION')'; containing folder location should be something like 'C:/Users/userName/Documents/EC-GPS/Offline'
    #RGUi: shiny::runApp('YOUR CONTAINING FOLDER LOCATION'); containing folder location should be something like 'C:/Users/userName/Documents/EC-GPS/Offline'
#5) upload desired data file and manipulate (can use included file 'LOG_MMDD.TXT' to test)
    # set time zone
    # filter by date
    # choose provinces to plot 
        # select from the drop-down menu
        # provinces can be removed by using the delete/backspace key in the dilog box
    # filter by EC value (check box and sliders)
    # Change the map zoom "region" shows the provincial extent and "data" shows just the data extent
    # Download Processed Data to .csv file that can be opened in Microsoft Excel or other text editor
    # Additionally Data can be sorted and searched using the Search bar and controls on the data table
####

#SERVER CODE BELOW
# load packages with multiple functions used
library(readr)
library(dplyr)
library(tidyr)
library(sp)
library(broom)
library(ggplot2)

## Get shapefiles for Canada
canada <- read_rds('GADM_2.8_CAN_adm1.rds')
## Alternatively can download from online -->
#canada <- raster::getData("GADM",country="CAN",level=1) ## requires 'raster' package be installed and will download to current directory (only need to run once)

#set default filter variable values
EC_default <- 500 ## default EC scale to 500 uS/cm
date1_default <- '2017-05-05'
date2_default <- '2017-07-05'

# Define server logic to upload data and output in table and on map
shinyServer(function(input, output, session) {
    ## Import Data
    datAll <- reactive({
        if(is.null(input$dataInput)) {return(NULL)}
        ## correct windows use of backslash--fileInput uses '/' giving mixed path.
        if(grepl('\\\\',input$dataInput$datapath)){
            filePath <- gsub('\\\\','/',input$dataInput$datapath)}
        else filePath <- input$dataInput$datapath
        dat3 <- read_csv(filePath, col_types = cols(year = col_integer(),
                                            month = col_integer(),
                                            day = col_integer(),
                                            hour_UTC = col_integer(),
                                            minute = col_integer(),
                                            second = col_integer(),
                                            lat = col_character(),
                                            lon = col_character(),
                                            altitude = col_double(),
                                            satellites = col_integer(),
                                            gps_fix = col_integer(),
                                            gps_fix_qual = col_integer(),
                                            batt = col_integer(),
                                            GS3_data = col_character())) %>% 
            ## concat datetime, seperate EC data, and lat lon data
            separate(GS3_data,c('GS3a','GS3b','GS3c','GS3d'), sep = '\\+') %>% 
            mutate('datetime_UTC' = as.POSIXct(paste(year,month,day,hour_UTC,minute,second, sep = ','), format = '%Y,%m,%d,%H,%M,%S', tz = "UTC"),
                   'lat_num' = as.numeric(sub(".$","",lat)),
                   'lon_num' = as.numeric(sub(".$","",lon))) %>% 
            ## change time zone and split date and time
            mutate("datetime" =format(datetime_UTC, tz = input$tzInput)) %>%
            mutate("date" = strftime(datetime, format="%Y-%m-%d"), "time" = strftime(datetime, format="%r")) %>% 
            ## convert coordinates to Decimal Degrees
            mutate('lat_dec' = round(lat_num %/% 100 + lat_num %% 100/60,6),
                   'lon_dec' = -round(lon_num %/% 100 + lon_num %% 100/60,6)) %>%
            ## get temp and EC and handle connection error
            mutate('temp' = as.numeric(ifelse(is.na(GS3c),-999, GS3c)),
                   'EC' = as.numeric(ifelse(is.na(GS3d),-999, GS3d))) %>% 
            ## convert battery to voltage (MAY WANT TO UPDATE THIS TO BE % CHARGE)
            mutate('battery_v' = round(batt*2*3.3/1024,1))
    })
    ## Create UI to filter by Date
    output$Date_filter <- renderUI({
        if(is.null(input$dataInput)) {
            date1 <- date1_default
            date2 <- date2_default
        }
        else{
            date1 <- min(datAll()$date)
            date2 <- max(datAll()$date)
        }
        dateRangeInput("dateRangeInput", "Date Range:", start = date1, end = date2) #default = current Date (else use: start/end = "2017-06-01")
    })
    
    
    ## Create UI for EC_scale (use default or round up to nearest 10)
    output$EC_filter <- renderUI({
        if(is.null(input$dataInput)) {EC_max <- EC_default}
        else {EC_max <- max(EC_default,round(max(datAll()$EC)+5, digits = -1))}
        sliderInput("ECInput", "EC-Value", 0, EC_max,c(0, EC_max), post = " uS/cm")
    })
    ## Create reactive data filter with EC and Date
    filtered <- reactive({
        if (is.null(datAll())) {
            return(NULL)
        } 
        filt <- datAll() %>%
            dplyr::select(date,time, temp, EC, lat_dec, lon_dec, satellites, gps_fix, gps_fix_qual, battery_v) %>%
            
        ## drop bad sats
            filter(abs(lat_dec) >=5, abs(lon_dec) >=5) %>% 
        ## implement date filter
            filter(date >= input$dateRangeInput[1],
                   date <= input$dateRangeInput[2])
        ## implement filter by EC
        if (is.null(input$ECFilter)) {return(filt)}
        if (input$ECFilter == FALSE) {return(filt)}
        if (input$ECFilter == TRUE) {
            filt %>% 
            filter(EC >= input$ECInput[1],
                   EC <= input$ECInput[2])}
    })
    
    # Text to troubleshoot (uncomment a line below and it will print reactively below map)
    output$result <- renderText({
        #paste0("file loc: ",input$dataInput$datapath)
        #input$dateRangeInput[1]
        #input$ECInput
        #input$ECFilter
        #input$tzInput
        #input$zoomInput
        #paste("xlim:")
    })
    
    # create interactive output table
    output$results <- DT::renderDataTable({
        if (length(filtered())==0) {return()}
        filtered()
    })
    
    #Code to Downlaod formatted Data
    output$dataDownload = downloadHandler(
        filename = function(){paste0('EC-GPS_data-',Sys.Date(),'.csv')},
        content = function(file) {
            write.csv(filtered(), file)})
    
    #Plot Data to Map
    ## plot provinces selected in UI
    ca.provinces <- reactive({
        if (is.null(input$provinceInput)) {return(NULL)}
        canada[canada$NAME_1 %in% input$provinceInput,]
    })
    ca.bbox <- reactive({bbox(ca.provinces())})
    xlim <- reactive({c(ca.bbox()[1,1],ca.bbox()[1,2])})
    ylim <- reactive({c(ca.bbox()[2,1],ca.bbox()[2,2])})
    
    ## create map
    output$map <- renderPlot({
        if(is.null(input$provinceInput)) {return(NULL)}
        ## Plot Regional Map
        if(input$zoomInput=='region'){
            plotmap <- ggplot(tidy(ca.provinces()),
                              aes(x = long, y = lat, xmin = min(xlim()), xmax = max(xlim()),
                                  ymin = min(ylim()), ymax = max(ylim())))+
                geom_path(aes(group = group))
            if(!is.null(input$dataInput)){
                plotmap+geom_point(data = filtered(), aes(x = lon_dec, y = lat_dec), color = "#990000")
            }
        }
        ## Plot Map Zoomed to Data
        else if(input$zoomInput=='data'&!is.null(input$dataInput)){
            xl <- range(filtered()$lon_dec)
            yl <- range(filtered()$lat_dec)
            ## plot window
            plotmap1 <- ggplot(filtered(),
                               aes(x = lon_dec, y = lat_dec,
                                   xmin = min(xl), xmax = max(xl), ymin = min(yl), ymax = max(yl)),
                               color = "#990000")
            ## plot provinces
            plotmap1+geom_path(data=tidy(ca.provinces()), aes(x = long, y = lat, group = group))
            ## plot data
            plotmap1 + geom_point(data = filtered(), aes(x = lon_dec, y = lat_dec), color = "#990000")
        }
    })
})
