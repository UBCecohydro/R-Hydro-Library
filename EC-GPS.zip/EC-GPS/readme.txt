I. DISTRIBUTION INCLUDES:
	A: readme.txt (this document with instructions on running the program)
	B: GoogleMaps folder (version of the program that plots data on google maps and allows point inspection). 
		Folder contains:
		1) server.R (R server file)
		2) ui.R (user interface file)
		3) www folder containing 'map.html' (html file with JSON code to plot points to google maps)
	C: Offline folder (version of the program that plots data on Canadian province polygons--no point inspection). 
		Folder contains:
		1) server.R (R server file)
		2) ui.R (user interface file)
		3) GADM_2.8_CAN_adm1.rds (provincial basemap for plotting data; can be downloaded by running raster::getData("GADM",country="CAN",level=1))
	D: LOG_MMDD.TXT (example EC-GPS logger output file to test GoogleMaps or Offline Shiny Apps)

II. INSTRUCTIONS:
	1) Make sure that R is installed on your computer (R downloads with RGUi by default; RStudio is optional but a bit nicer)
		R can be installed from here: https://cran.rstudio.com/
		RStudio can be installed from here: https://www.rstudio.com/products/rstudio/download/#download
		Good instructions about setting up R and RStudio can be found here: http://stat545.com/block000_r-rstudio-install.html
	2) Make sure that all needed R packages are installed and up to date; This code was built with R version 3.5.0 (2018-04-23)
		## CODE to install needed packages (if asked install dependancies)
			install.packages(c('shiny','readr','DT','RJSONIO','dplyr','tidyr','sp','broom','ggplot2'))
		## CODE to update needed packages (if previously installed)
			update.packages(c('shiny','readr','DT','RJSONIO','dplyr','tidyr','sp','broom','ggplot2'))
			# alternatively all packages can be updated with:
			update.packages(ask = FALSE, checkBuilt = TRUE)
	3) Ensure that the needed files are in the same folder; either
		a) GoogleMaps: 'ui.R' file, 'server.R' file, and 'www' folder (containing 'map.html'), or
		b) Offline: 'ui.R' file, 'server.R' file, and 'GADM_2.8_CAN_adm1.rds' file
	4) Run the selected Shiny app (GoogleMaps or Offline) in RGUi or RStudio
		a) RGui: shiny::runApp('YOUR CONTAINING FOLDER LOCATION')
			containing folder location should be something like
				'C:/Users/userName/Documents/EC-GPS/GoogleMaps', or
				'C:/Users/userName/Documents/EC-GPS/Offline'
		b) RStudio: Two options (1) open ui.R or server.R and click "Run App" button, or 
			(2) in Console run 'shiny::runApp()' or 'shiny::runApp('YOUR CONTAINING FOLDER LOCATION')'; 
				containing folder location should be something like
				'C:/Users/userName/Documents/EC-GPS/GoogleMaps', or
				'C:/Users/userName/Documents/EC-GPS/Offline' 
			Note: for running the "GoogleMaps" Shiny App 
				(depending on RStudio settings) you may need to click the "Open in Browser" button 
	5) upload desired data log file and manipulate (can use included file 'LOG_MMDD.TXT' to test)
		a. set time zone
		b. filter by date (if mutiple files have been copied together)
		c. filter by EC value (check box and sliders)
		d. plot to map
			i) for GoogleMaps: "Plot Data"
				Note 1: data needs to be replotted after filters are changed
				Note 2: clicking on data points on the map displays the details associated
			ii) for Offline: (1) choose provinces to plot
					select from the drop-down menu,
					provinces can be removed by using the delete/backspace key in the dilog box
				(2) Change the map Zoom
					"region" shows the provincial extent
					"data" shows just the data extent
		e. Download Processed Data to .csv file that can be opened in Microsoft Excel or other text editor
		f. Additionally Data can be sorted and searched using the Search bar and controls on the data table